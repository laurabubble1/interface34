# passage en mode automatique


# detecter le balise

def detecter(aruco): #detecte si le robot voit la balise et aussi si c'est la bonne
    return

def distance(aruco): #determine la distance entre le robot et la balise si possible
    return

def avancer(): # avance léger (pas en continu comme les commandes manuelles)
    return

def demi_tour(): # fait demi tour
    return


def basculer(): # fonction qui cherche la balise globalement elle doit faire tourner et avancer le robot
    return  